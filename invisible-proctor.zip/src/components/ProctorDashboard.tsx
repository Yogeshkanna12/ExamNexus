import React, { useState, useEffect } from 'react';
import { ProctorEvent, ProctorMetrics, RiskHistoryData } from '../hooks/useProctor';
import { Shield, AlertTriangle, MousePointerClick, Keyboard, Eye, EyeOff, ClipboardPaste } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { LineChart, Line, ResponsiveContainer, YAxis } from 'recharts';

export function ProctorDashboard({
  riskScore,
  riskHistory,
  events,
  metrics,
  alertThreshold = 75,
}: {
  riskScore: number;
  riskHistory: RiskHistoryData[];
  events: ProctorEvent[];
  metrics: ProctorMetrics;
  alertThreshold?: number;
}) {
  const [showAlert, setShowAlert] = useState(false);
  const [prevScore, setPrevScore] = useState(riskScore);

  useEffect(() => {
    if (riskScore >= alertThreshold && prevScore < alertThreshold) {
      setShowAlert(true);
      const timer = setTimeout(() => setShowAlert(false), 3000);
      return () => clearTimeout(timer);
    }
    setPrevScore(riskScore);
  }, [riskScore, prevScore, alertThreshold]);

  const getRiskColor = (score: number) => {
    if (score < 20) return 'text-emerald-500';
    if (score < 50) return 'text-amber-500';
    if (score < alertThreshold) return 'text-orange-500';
    return 'text-rose-500';
  };

  return (
    <div className={`relative flex flex-col h-full gap-4 transition-all duration-500 ${showAlert ? 'shadow-[0_0_50px_rgba(244,63,94,0.15)] ring-1 ring-rose-500/50 rounded-3xl' : ''}`}>
      {/* Alert Toast Overlay */}
      <AnimatePresence>
        {showAlert && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            className="absolute top-4 left-1/2 transform -translate-x-1/2 z-50 bg-rose-500/90 backdrop-blur-md border border-rose-400 text-white px-5 py-2.5 rounded-full shadow-2xl flex items-center gap-2.5 pointer-events-none"
          >
            <AlertTriangle className="w-4 h-4 animate-pulse" />
            <span className="text-xs font-bold tracking-widest uppercase">Threshold Exceeded</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Behavior Risk Score (Hero Gauge) */}
      <section className="bg-gradient-to-br from-[#18181b] to-[#111114] border border-[#27272a] rounded-3xl p-6 flex flex-col items-center justify-center relative overflow-hidden flex-shrink-0 min-h-[220px]">
        <div className="absolute top-4 left-4">
          <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Risk Index</p>
        </div>
        <div className="absolute top-4 right-4 text-[10px] bg-indigo-500/10 text-indigo-400 px-2 py-1 rounded border border-indigo-500/20 font-bold uppercase tracking-wider">
          Live Analysis
        </div>
        
        <div className="relative flex items-center justify-center mt-2">
          <svg className="w-32 h-32 transform -rotate-90">
            <circle
              cx="64"
              cy="64"
              r="56"
              fill="transparent"
              stroke="currentColor"
              strokeWidth="10"
              className="text-[#27272a]"
            />
            <motion.circle
              cx="64"
              cy="64"
              r="56"
              fill="transparent"
              stroke="currentColor"
              strokeWidth="10"
              strokeDasharray={351.86}
              strokeDashoffset={351.86 - (351.86 * riskScore) / 100}
              className={`${getRiskColor(riskScore)} transition-all duration-200 ease-linear`}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute flex flex-col items-center justify-center text-center">
            <span className={`text-4xl font-black ${getRiskColor(riskScore)}`}>
              {Math.round(riskScore)}%
            </span>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">Status: {riskScore < 50 ? 'Secure' : 'Review'}</span>
          </div>
        </div>
      </section>

      {/* Metrics Grid */}
      <section className="bg-[#18181b] border border-[#27272a] rounded-3xl p-5 grid grid-cols-2 gap-3 flex-shrink-0">
        <div className="bg-[#27272a]/30 p-3.5 rounded-2xl flex flex-col justify-center border border-[#27272a]/50">
          <p className="text-[10px] text-indigo-400 font-bold mb-1 flex items-center gap-1.5"><Keyboard className="w-3 h-3" /> WPM</p>
          <p className="text-2xl font-black text-slate-100">{metrics.wpm}</p>
          <p className="text-[10px] text-slate-500 mt-0.5">Typing Speed</p>
        </div>
        
        <div className="bg-[#27272a]/30 p-3.5 rounded-2xl flex flex-col justify-center border border-[#27272a]/50">
          <p className="text-[10px] text-indigo-400 font-bold mb-1 flex items-center gap-1.5">
            {metrics.isTabActive ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />} TAB
          </p>
          <p className={`text-lg font-black ${metrics.isTabActive ? 'text-emerald-500' : 'text-rose-500'}`}>
            {metrics.isTabActive ? 'Focused' : 'Background'}
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">Window Status</p>
        </div>
        
        <div className="col-span-2 bg-[#27272a]/30 p-3.5 rounded-2xl flex flex-col justify-center border border-[#27272a]/50 relative overflow-hidden">
           <div className="flex justify-between items-center mb-1">
             <p className="text-[10px] text-indigo-400 font-bold flex items-center gap-1.5"><MousePointerClick className="w-3 h-3" /> CURSOR</p>
             <div className="flex items-center gap-1.5">
               <div className={`w-1.5 h-1.5 rounded-full ${metrics.isMouseInWindow ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`}></div>
               <span className={`text-[10px] font-bold tracking-wider uppercase ${metrics.isMouseInWindow ? 'text-emerald-500' : 'text-amber-500'}`}>
                 {metrics.isMouseInWindow ? 'In Bounds' : 'Out of Bounds'}
               </span>
             </div>
           </div>
           <div className="h-8 flex items-center justify-between w-full mt-1 bg-[#09090b]/50 rounded border border-[#27272a]/30 px-2">
              <div className="flex gap-0.5 opacity-60">
               {[...Array(20)].map((_, i) => (
                  <div key={i} style={{ height: `${Math.max(8, Math.floor(Math.random() * 24))}px` }} className={`w-1 rounded-full ${metrics.isMouseInWindow ? 'bg-indigo-500/40' : 'bg-indigo-500/10'}`}></div>
                ))}
              </div>
           </div>
        </div>
      </section>

      {/* Risk Over Time Chart */}
      <section className="bg-[#18181b] border border-[#27272a] rounded-3xl p-5 flex-shrink-0">
        <div className="flex justify-between items-center mb-2">
          <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Risk Volatility</p>
          <div className="flex gap-1">
             <div className="w-1 h-2 bg-indigo-500 rounded-full animate-pulse"></div>
             <div className="w-1 h-4 bg-indigo-500 rounded-full animate-pulse delay-75"></div>
             <div className="w-1 h-3 bg-indigo-500 rounded-full animate-pulse delay-150"></div>
          </div>
        </div>
        <div className="h-20 w-full mt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={riskHistory}>
              <YAxis domain={[0, 100]} hide />
              <Line 
                type="linear" 
                dataKey="score" 
                stroke="#8b5cf6" 
                strokeWidth={2} 
                dot={false}
                isAnimationActive={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Event Log */}
      <section className="flex-1 min-h-[200px] bg-[#18181b] border border-[#27272a] rounded-3xl p-5 flex flex-col overflow-hidden">
        <div className="flex justify-between items-center mb-4">
          <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Event Manifest</p>
          <span className="text-[10px] text-slate-500 font-mono bg-[#27272a]/50 px-2 py-0.5 rounded-full">{events.length}</span>
        </div>
        
        <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
          <AnimatePresence initial={false}>
            {events.length === 0 ? (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center h-full text-slate-500 gap-3 opacity-60"
              >
                <div className="w-10 h-10 rounded-xl bg-[#27272a]/30 flex items-center justify-center border border-[#27272a]/50">
                  <Shield className="w-5 h-5 text-slate-400" />
                </div>
                <span className="text-xs font-semibold uppercase tracking-wider">Awaiting Signals</span>
              </motion.div>
            ) : (
              events.map((event) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex gap-3 items-start"
                >
                  <div className="mt-1 flex-shrink-0">
                    <div className="w-2 h-2 rounded-full mt-1.5" style={{ backgroundColor: event.impact > 20 ? '#f43f5e' : event.impact > 10 ? '#f59e0b' : '#3b82f6' }}></div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start">
                      <p className="text-sm font-semibold text-slate-200">{event.message}</p>
                      <span className={`text-[10px] font-bold ${getRiskColor(event.impact * 10)} ml-2`}>+{event.impact}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                       <span className="text-[10px] text-slate-500 font-mono">
                         {event.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                       </span>
                       <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider opacity-60">
                         {event.type.replace('_', ' ')}
                       </span>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </section>
    </div>
  );
}
