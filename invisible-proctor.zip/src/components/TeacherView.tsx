import React, { useState } from 'react';
import { ProctorDashboard } from './ProctorDashboard';
import { Plus, Trash2, Shield, FileText } from 'lucide-react';
import { useProctor } from '../hooks/useProctor';

export function TeacherView({ questions, addQuestion, deleteQuestion }: any) {
  const [activeTab, setActiveTab] = useState<'monitoring' | 'exam'>('monitoring');
  const { riskScore, riskHistory, events, metrics } = useProctor();
  const [newQuestion, setNewQuestion] = useState('');

  const handleAdd = () => {
    if (newQuestion.trim()) {
      addQuestion(newQuestion);
      setNewQuestion('');
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#18181b] border border-[#27272a] rounded-3xl overflow-hidden shadow-sm w-full max-w-3xl mx-auto">
      <div className="flex border-b border-[#27272a] bg-[#09090b]/50 p-2 gap-2 flex-shrink-0">
        <button 
          onClick={() => setActiveTab('monitoring')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all ${activeTab === 'monitoring' ? 'bg-[#27272a] text-indigo-400' : 'text-slate-500 hover:text-slate-300'}`}
        >
          <Shield className="w-4 h-4" /> Live Monitoring
        </button>
        <button 
          onClick={() => setActiveTab('exam')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all ${activeTab === 'exam' ? 'bg-[#27272a] text-indigo-400' : 'text-slate-500 hover:text-slate-300'}`}
        >
          <FileText className="w-4 h-4" /> Exam Config
        </button>
      </div>

      <div className="flex-1 overflow-hidden">
        {activeTab === 'monitoring' ? (
          <div className="h-full p-4 md:p-6 overflow-y-auto custom-scrollbar">
            <ProctorDashboard 
              riskScore={riskScore}
              riskHistory={riskHistory}
              events={events}
              metrics={metrics}
            />
          </div>
        ) : (
          <div className="h-full flex flex-col p-6 md:p-8 overflow-y-auto custom-scrollbar">
            <h2 className="text-xl font-bold text-slate-100 mb-6">Manage Exam Questions</h2>
            
            <div className="mb-8 bg-[#09090b]/50 border border-[#27272a] p-4 md:p-6 rounded-2xl flex-shrink-0">
              <label className="block text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-2">Add New Question</label>
              <textarea
                className="w-full h-24 md:h-32 p-4 border border-[#27272a] rounded-xl focus:ring-1 focus:ring-indigo-500/50 outline-none bg-[#18181b] text-slate-200 resize-none font-sans mb-3 text-sm placeholder-slate-600"
                placeholder="Type the exam question here..."
                value={newQuestion}
                onChange={e => setNewQuestion(e.target.value)}
              />
              <div className="flex justify-end">
                <button 
                  onClick={handleAdd}
                  disabled={!newQuestion.trim()}
                  className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold py-2 px-4 rounded-lg flex items-center gap-2 text-sm transition-colors border border-indigo-500/50"
                >
                  <Plus className="w-4 h-4" /> Add Question
                </button>
              </div>
            </div>

            <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 flex-shrink-0">Current Questions ({questions.length})</h3>
            <div className="space-y-4">
              {questions.map((q: any, idx: number) => (
                <div key={q.id} className="bg-[#18181b] border border-[#27272a] p-4 rounded-xl flex gap-4 items-start shadow-sm">
                  <div className="flex-shrink-0 w-6 h-6 flex items-center justify-center rounded bg-[#27272a] text-xs font-bold text-indigo-400 mt-0.5">
                    {idx + 1}
                  </div>
                  <p className="flex-1 text-sm text-slate-300 leading-relaxed font-sans whitespace-pre-wrap">
                    {q.text}
                  </p>
                  <button 
                    onClick={() => deleteQuestion(q.id)}
                    className="text-slate-500 hover:text-rose-500 transition-colors p-1 flex-shrink-0 bg-[#09090b]/50 rounded-md border border-[#27272a] hover:border-rose-500/50"
                    title="Delete Question"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
              {questions.length === 0 && (
                <p className="text-slate-500 text-sm italic text-center py-8">No questions added yet.</p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
