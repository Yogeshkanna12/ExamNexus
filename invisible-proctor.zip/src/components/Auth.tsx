import React, { useState } from 'react';

export function Auth({ role, onLogin }: { role: 'student' | 'teacher', onLogin: (email: string, role: 'student' | 'teacher') => void }) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please fill all fields');
      return;
    }
    
    const users = JSON.parse(localStorage.getItem('sentinel_users') || '{}');
    
    if (isLogin) {
      if (users[email] && users[email].password === password && users[email].role === role) {
        onLogin(email, role);
      } else {
        setError('Invalid credentials or wrong role');
      }
    } else {
      if (users[email]) {
        setError('User already exists');
      } else {
        users[email] = { password, role };
        localStorage.setItem('sentinel_users', JSON.stringify(users));
        onLogin(email, role);
      }
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-full p-8 w-full max-w-md mx-auto">
      <div className="w-full bg-[#18181b] border border-[#27272a] rounded-3xl p-8 shadow-xl">
        <h2 className="text-2xl font-bold text-slate-100 mb-6 text-center">
          {role === 'teacher' ? "Teacher Access" : "Student Access"}
        </h2>
        <div className="flex justify-center mb-6 bg-[#09090b] p-1 rounded-lg border border-[#27272a]">
            <button 
                type="button"
                onClick={() => {setIsLogin(true); setError('');}}
                className={`flex-1 px-4 py-2 rounded-md text-xs font-bold uppercase tracking-wider transition-all ${isLogin ? 'bg-indigo-500 text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
                Login
            </button>
            <button 
                type="button"
                onClick={() => {setIsLogin(false); setError('');}}
                className={`flex-1 px-4 py-2 rounded-md text-xs font-bold uppercase tracking-wider transition-all ${!isLogin ? 'bg-indigo-500 text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
                Sign Up
            </button>
        </div>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-1">Email</label>
            <input 
              type="email" 
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full p-3 bg-[#09090b]/50 border border-[#27272a] rounded-xl focus:ring-1 focus:ring-indigo-500/50 outline-none text-slate-200 font-sans"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label className="block text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-1">Password</label>
            <input 
              type="password" 
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full p-3 bg-[#09090b]/50 border border-[#27272a] rounded-xl focus:ring-1 focus:ring-indigo-500/50 outline-none text-slate-200 font-sans"
              placeholder="••••••••"
            />
          </div>
          {error && <p className="text-rose-500 text-xs font-bold">{error}</p>}
          <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-xl transition-colors mt-2 uppercase tracking-wider text-xs shadow-sm shadow-indigo-500/20">
            {isLogin ? 'Enter Space' : 'Create Account'}
          </button>
        </form>
      </div>
    </div>
  );
}
