import React, { useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { Question } from '../hooks/useData';

export function ExamView({ questions }: { questions: Question[] }) {
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center bg-[#18181b] rounded-3xl">
        <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center border border-emerald-500/20 mb-6">
          <CheckCircle2 className="w-10 h-10 text-emerald-500" />
        </div>
        <h2 className="text-2xl font-bold text-slate-100 mb-2">Exam Submitted Successfully</h2>
        <p className="text-slate-500 text-sm">Your answers and behavioral data have been securely transmitted to the proctor node.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full p-6 md:p-8">
      <div className="mb-6 md:mb-8 border-b border-[#27272a] pb-4 flex-shrink-0">
        <div className="flex justify-between items-start">
          <div>
            <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-2 py-1 rounded border border-indigo-500/20 font-bold uppercase tracking-wider mb-3 inline-block">Examining</span>
            <h2 className="text-xl md:text-2xl font-bold text-slate-100">Final Examination: Advanced Ethics</h2>
            <p className="text-slate-500 mt-2 text-sm">CS-402 • Spring Semester</p>
          </div>
          <div className="text-right">
             <div className="inline-flex items-center gap-2 bg-[#09090b]/50 px-3 py-1.5 rounded-md border border-[#27272a]">
               <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
               <span className="text-sm font-medium text-slate-300 font-mono">59:23</span>
             </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 md:pr-4 space-y-10">
        {questions.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-slate-500 opacity-60">
            <p className="text-sm font-medium">No questions have been assigned for this exam.</p>
            <p className="text-xs mt-2">Waiting for teacher configuration...</p>
          </div>
        ) : (
          questions.map((q, idx) => (
            <div key={q.id}>
              <div className="flex gap-4 items-start mb-4">
                <span className="flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 font-semibold text-sm">
                  {idx + 1}
                </span>
                <div>
                  <h3 className="text-lg font-medium text-slate-200 mb-2">Question {idx + 1}</h3>
                  <p className="text-slate-400 leading-relaxed text-sm md:text-base font-sans whitespace-pre-wrap">
                    {q.text}
                  </p>
                </div>
              </div>
              
              <div className="pl-12">
                <textarea
                  className="w-full h-48 md:h-64 p-4 border border-[#27272a] rounded-xl focus:ring-1 focus:ring-indigo-500/50 focus:border-indigo-500/50 bg-[#09090b]/50 text-slate-100 resize-none transition-all outline-none text-base placeholder-slate-600 font-sans"
                  placeholder="Begin typing your answer here..."
                  value={answers[q.id] || ''}
                  onChange={(e) => setAnswers({...answers, [q.id]: e.target.value})}
                />
              </div>
            </div>
          ))
        )}
      </div>
      
      <div className="mt-4 pt-4 border-t border-[#27272a] flex justify-end flex-shrink-0">
        <button 
          onClick={() => setSubmitted(true)}
          disabled={questions.length === 0}
          className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold py-2 px-6 rounded-xl transition-colors shadow-sm cursor-pointer border border-indigo-500/50 hover:shadow-indigo-500/20 flex items-center gap-2"
        >
          <CheckCircle2 className="w-4 h-4" />
          Submit Exam
        </button>
      </div>
    </div>
  );
}
