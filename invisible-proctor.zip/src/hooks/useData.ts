import { useState, useEffect } from 'react';

export type UserRole = 'student' | 'teacher';

export type UserSession = {
  email: string;
  role: UserRole;
};

export type Question = {
  id: string;
  text: string;
};

export function useData() {
  const [user, setUser] = useState<UserSession | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);

  useEffect(() => {
    const storedUser = localStorage.getItem('sentinel_user');
    if (storedUser) setUser(JSON.parse(storedUser));

    const storedQuestions = localStorage.getItem('sentinel_questions');
    if (storedQuestions) {
        setQuestions(JSON.parse(storedQuestions));
    } else {
        const defaultQ = [{ 
          id: '1', 
          text: 'Discuss the implications of utilitarianism in modern software engineering. Provide specific examples of how prioritizing the "greatest good" might conflict with individual user privacy rights. (Minimum 500 words).' 
        }];
        setQuestions(defaultQ);
        localStorage.setItem('sentinel_questions', JSON.stringify(defaultQ));
    }
  }, []);

  const login = (email: string, role: UserRole) => {
    const session = { email, role };
    setUser(session);
    localStorage.setItem('sentinel_user', JSON.stringify(session));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('sentinel_user');
  };

  const addQuestion = (text: string) => {
    const newQuestions = [...questions, { id: Math.random().toString(36).substring(2, 9), text }];
    setQuestions(newQuestions);
    localStorage.setItem('sentinel_questions', JSON.stringify(newQuestions));
  };

  const deleteQuestion = (id: string) => {
    const newQuestions = questions.filter(q => q.id !== id);
    setQuestions(newQuestions);
    localStorage.setItem('sentinel_questions', JSON.stringify(newQuestions));
  };

  return { user, login, logout, questions, addQuestion, deleteQuestion };
}
