import { useState, useEffect, useCallback, useRef } from 'react';

export type ProctorEvent = {
  id: string;
  type: 'tab_switch' | 'copy' | 'paste' | 'mouse_leave' | 'typing_burst' | 'idle';
  message: string;
  timestamp: Date;
  impact: number;
};

export type ProctorMetrics = {
  wpm: number;
  isTabActive: boolean;
  isMouseInWindow: boolean;
};

export type RiskHistoryData = {
  time: string;
  score: number;
};

export function useProctor() {
  const [riskScore, setRiskScore] = useState(0);
  const [riskHistory, setRiskHistory] = useState<RiskHistoryData[]>([]);
  const riskScoreRef = useRef(0);
  const [events, setEvents] = useState<ProctorEvent[]>([]);
  const [metrics, setMetrics] = useState<ProctorMetrics>({
    wpm: 0,
    isTabActive: true,
    isMouseInWindow: true,
  });

  const keyStrokesRef = useRef<number[]>([]);
  const lastInteractionRef = useRef<number>(Date.now());
  const lastBurstEventRef = useRef<number>(0);
  const lastIdleEventRef = useRef<number>(0);

  const addEvent = useCallback((type: ProctorEvent['type'], message: string, impact: number) => {
    setEvents(prev => [{
      id: Math.random().toString(36).substring(2, 9),
      type,
      message,
      timestamp: new Date(),
      impact
    }, ...prev].slice(0, 50)); 
    
    setRiskScore(prev => {
      const newScore = Math.min(100, prev + impact);
      riskScoreRef.current = newScore;
      return newScore;
    });
  }, []);

  useEffect(() => {
    const handleVisibilityChange = () => {
      const isHidden = document.hidden;
      setMetrics(prev => ({ ...prev, isTabActive: !isHidden }));
      if (isHidden) {
        addEvent('tab_switch', 'Student switched tabs or minimized window', 25);
      }
    };

    const handleCopy = (e: ClipboardEvent) => {
      addEvent('copy', 'Text copied to clipboard', 10);
    };

    const handlePaste = (e: ClipboardEvent) => {
      addEvent('paste', 'Text pasted from clipboard', 30);
    };

    const handleMouseLeave = () => {
      setMetrics(prev => ({ ...prev, isMouseInWindow: false }));
      addEvent('mouse_leave', 'Mouse cursor left the exam window', 5);
    };

    const handleMouseEnter = () => {
      setMetrics(prev => ({ ...prev, isMouseInWindow: true }));
    };
    
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key.length === 1 || e.key === 'Backspace' || e.key === 'Enter') {
        const now = Date.now();
        keyStrokesRef.current.push(now);
        lastInteractionRef.current = now;
      }
    };
    
    const handleMouseMove = () => {
        lastInteractionRef.current = Date.now();
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('copy', handleCopy);
    document.addEventListener('paste', handlePaste);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('mousemove', handleMouseMove);

    const interval = setInterval(() => {
      const now = Date.now();
      
      const tenSecondsAgo = now - 10000;
      keyStrokesRef.current = keyStrokesRef.current.filter(time => time > tenSecondsAgo);
      
      const currentWpm = Math.round((keyStrokesRef.current.length / 5) * 6);
      setMetrics(prev => ({ ...prev, wpm: currentWpm }));

      if (currentWpm > 100) {
        if (now - lastBurstEventRef.current > 15000) {
           addEvent('typing_burst', 'Unnatural typing speed detected (>100 WPM)', 15);
           lastBurstEventRef.current = now;
        }
      }

      const idleTime = now - lastInteractionRef.current;
      if (idleTime > 30000) { 
        if (now - lastIdleEventRef.current > 35000) {
           addEvent('idle', 'Prolonged inactivity detected', 5);
           lastIdleEventRef.current = now;
        }
      }

      setRiskHistory(prev => {
        const timeLabel = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', fractionalSecondDigits: 1 });
        const newHistory = [...prev, { time: timeLabel, score: riskScoreRef.current }];
        // Keep last 100 data points for a smooth fast graph
        return newHistory.slice(-100);
      });

    }, 250);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      document.removeEventListener('copy', handleCopy);
      document.removeEventListener('paste', handlePaste);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('mousemove', handleMouseMove);
      clearInterval(interval);
    };
  }, [addEvent]);

  return { riskScore, riskHistory, events, metrics };
}
