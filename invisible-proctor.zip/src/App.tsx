/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ExamView } from './components/ExamView';
import { TeacherView } from './components/TeacherView';
import { Auth } from './components/Auth';
import { useData } from './hooks/useData';
import { LogOut, BookCopy } from 'lucide-react';

export default function App() {
  const [activeSpace, setActiveSpace] = useState<'student' | 'teacher'>('student');
  const { user, login, logout, questions, addQuestion, deleteQuestion } = useData();

  return (
    <div className="min-h-screen bg-[#09090b] text-slate-100 p-4 md:p-6 font-sans selection:bg-indigo-500/30 flex flex-col gap-6">
      
      {/* Title Card */}
      <div className="max-w-7xl mx-auto w-full text-center py-4 border-b border-[#27272a] bg-gradient-to-r from-transparent via-[#18181b] to-transparent rounded-3xl relative">
        <h1 className="text-3xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-br from-white to-slate-500 uppercase tracking-widest">
          ExamNexus
        </h1>
        {user && (
          <button 
            onClick={logout}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors flex items-center gap-2 text-xs font-bold uppercase"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        )}
      </div>

      {/* Header Navigation */}
      <header className="flex flex-col md:flex-row justify-between items-center bg-[#18181b] border border-[#27272a] rounded-2xl px-6 py-4 max-w-7xl mx-auto w-full gap-4 md:gap-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-500/10 border border-indigo-500/30 rounded-xl flex items-center justify-center text-indigo-400">
            <BookCopy className="w-5 h-5" />
          </div>
        </div>

        {/* Space Toggle Options */}
        <div className="flex bg-[#09090b] p-1 rounded-lg border border-[#27272a]">
          <button 
            onClick={() => setActiveSpace('student')}
            className={`px-4 sm:px-6 py-2 rounded-md text-xs font-bold uppercase tracking-wider transition-all ${
              activeSpace === 'student' 
                ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/20' 
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            Student's space
          </button>
          <button 
            onClick={() => setActiveSpace('teacher')}
            className={`px-4 sm:px-6 py-2 rounded-md text-xs font-bold uppercase tracking-wider transition-all ${
              activeSpace === 'teacher' 
                ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/20' 
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            Teacher's space
          </button>
        </div>

        <div className="flex items-center gap-6 hidden lg:flex">
          <div className="flex flex-col items-end">
            <span className="text-xs text-slate-500 uppercase tracking-widest font-semibold">Active Session</span>
            <span className="text-sm text-slate-200 font-mono">
              {user ? user.email : 'NOT_LOGGED_IN'}
            </span>
          </div>
          <div className="h-8 w-[1px] bg-slate-800 hidden md:block"></div>
          <div className="items-center gap-3 hidden md:flex">
            <div className="text-right">
              <p className="text-sm font-medium">{user ? (user.role === 'teacher' ? 'Admin' : 'Student') : 'Guest'}</p>
              <p className="text-[10px] text-slate-500">Access Level</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-indigo-900/50 border border-indigo-500/30"></div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto w-full flex-1 flex flex-col h-full min-h-[500px]">
        {activeSpace === 'student' ? (
          <section className="w-full flex-1 flex flex-col h-full bg-[#18181b] border border-[#27272a] rounded-3xl overflow-hidden shadow-sm">
             {user?.role === 'student' ? (
               <ExamView questions={questions} />
             ) : (
               <Auth role="student" onLogin={login} />
             )}
          </section>
        ) : (
          <section className="w-full flex-1 flex flex-col h-full">
            {user?.role === 'teacher' ? (
              <TeacherView questions={questions} addQuestion={addQuestion} deleteQuestion={deleteQuestion} />
            ) : (
               <Auth role="teacher" onLogin={login} />
            )}
          </section>
        )}
      </main>

      {/* Footer / Status Bar */}
      <footer className="max-w-7xl mx-auto w-full flex justify-between items-center text-[10px] text-slate-500 px-2 py-2">
        <div className="flex gap-4 md:gap-6 uppercase tracking-widest font-bold">
          <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div> AES-256</span>
          <span className="hidden sm:flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div> Behavioral Signatures</span>
          <span className="hidden md:flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div> Camera Disabled</span>
        </div>
        <div className="uppercase tracking-widest font-bold">
          © {new Date().getFullYear()} SENTINEL PROTOCOLS LTD.
        </div>
      </footer>
    </div>
  );
}
